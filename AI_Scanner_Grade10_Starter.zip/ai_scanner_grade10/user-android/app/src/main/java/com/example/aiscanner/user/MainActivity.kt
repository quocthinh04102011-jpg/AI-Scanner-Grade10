package com.example.aiscanner.user

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Neon = Color(0xFFC084FC)
private val Deep = Color(0xFF160D24)
private val Card = Color(0xFF2A1740)
private val subjects = listOf("Toán","Ngữ văn","Tiếng Anh","Vật lý","Hóa học","Sinh học",
    "Lịch sử","Địa lý","Tin học","Công nghệ","GD Kinh tế & Pháp luật",
    "GD Quốc phòng & An ninh","GD Thể chất","Hoạt động trải nghiệm")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var username by remember { mutableStateOf("") }
            var password by remember { mutableStateOf("") }
            var loggedIn by remember { mutableStateOf(false) }
            var subject by remember { mutableStateOf("AI tự nhận diện") }
            var answer by remember { mutableStateOf("") }
            var showResult by remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon, background = Deep, surface = Card)) {
                Surface(Modifier.fillMaxSize(), color = Deep) {
                    if (!loggedIn) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("AI SCANNER", style = MaterialTheme.typography.headlineMedium, color = Neon)
                            Text("USER · LỚP 10", color = Neon)
                            OutlinedTextField(username, { username = it }, label = { Text("Tài khoản") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(password, { password = it }, label = { Text("Mật khẩu") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { loggedIn = username.isNotBlank() && password.isNotBlank() }, modifier = Modifier.fillMaxWidth()) { Text("Đăng nhập demo") }
                            Text("Demo giao diện: đăng nhập thật cần kết nối Backend.", color = Color.LightGray)
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            item {
                                Text("AI SCANNER", style = MaterialTheme.typography.headlineMedium, color = Neon)
                                Text("FULL MÔN · LỚP 10", color = Neon)
                                Card(shape = RoundedCornerShape(18.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Chọn môn học", color = Neon)
                                        subjects.forEach { s ->
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                RadioButton(selected = subject == s, onClick = { subject = s })
                                                Text(s)
                                            }
                                        }
                                    }
                                }
                                Button(onClick = {
                                    answer = "Bản demo: chọn vùng màn hình và kết nối AI Cloud để nhận lời giải."
                                    showResult = true
                                }, modifier = Modifier.fillMaxWidth()) { Text("▣  QUÉT / GIẢI BÀI") }
                                OutlinedButton(onClick = {
                                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:$packageName")))
                                    } else startService(Intent(this@MainActivity, FloatingBubbleService::class.java))
                                }, modifier = Modifier.fillMaxWidth()) { Text("Bật bong bóng nổi") }
                                Text("Lịch sử quét", color = Neon)
                                Text("Chưa có lịch sử. Kết quả demo không được lưu.", color = Color.LightGray)
                            }
                        }
                    }
                    if (showResult) AlertDialog(onDismissRequest = { showResult = false },
                        title = { Text("AI Scanner · $subject") },
                        text = { Text(answer) },
                        confirmButton = { TextButton(onClick = { showResult = false }) { Text("Đóng") } })
                }
            }
        }
    }
}
