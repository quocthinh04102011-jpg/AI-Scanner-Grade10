package com.example.aiscanner.user

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color
import android.view.MotionEvent

class FloatingBubbleService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "AI"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF7C3AED.toInt())
            gravity = Gravity.CENTER
            setPadding(18, 12, 18, 12)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 220 }
        bubble?.setOnTouchListener(object : android.view.View.OnTouchListener {
            var downX = 0; var downY = 0; var startX = 0; var startY = 0
            override fun onTouch(v: android.view.View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX.toInt(); downY = event.rawY.toInt()
                        startX = params.x; startY = params.y; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + event.rawX.toInt() - downX
                        params.y = startY + event.rawY.toInt() - downY
                        windowManager?.updateViewLayout(bubble, params); return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
        windowManager?.addView(bubble, params)
    }
    override fun onDestroy() { bubble?.let { windowManager?.removeView(it) }; bubble = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
