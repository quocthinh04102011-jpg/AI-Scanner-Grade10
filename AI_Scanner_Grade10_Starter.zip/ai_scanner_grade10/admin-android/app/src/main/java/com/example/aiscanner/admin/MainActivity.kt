package com.example.aiscanner.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Neon = Color(0xFFC084FC)
private val Deep = Color(0xFF160D24)
private val Card = Color(0xFF2A1740)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var username by remember { mutableStateOf("") }
            var password by remember { mutableStateOf("") }
            var admin by remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon, background = Deep, surface = Card)) {
                Surface(Modifier.fillMaxSize(), color = Deep) {
                    if (!admin) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("AI SCANNER ADMIN", style = MaterialTheme.typography.headlineMedium, color = Neon)
                            OutlinedTextField(username, { username = it }, label = { Text("Admin account") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { admin = username.isNotBlank() && password.isNotBlank() }, modifier = Modifier.fillMaxWidth()) { Text("Đăng nhập demo") }
                            Text("Demo only — cần xác thực Backend trước khi triển khai.", color = Color.LightGray)
                        }
                    } else {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("ADMIN DASHBOARD", style = MaterialTheme.typography.headlineMedium, color = Neon)
                            Text("AI SCANNER · LỚP 10", color = Neon)
                            val sections = listOf(
                                "Tạo tài khoản User", "Khóa / mở khóa tài khoản",
                                "Đặt hạn sử dụng", "Quản lý thiết bị",
                                "Cấu hình AI Provider", "Chọn AI Model",
                                "Gửi thông báo", "Nhật ký hoạt động"
                            )
                            sections.forEach { title ->
                                Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(title)
                                        Text("›", color = Neon)
                                    }
                                }
                            }
                            Text("Các mục hiện là giao diện mẫu; kết nối API Admin để thực thi.", color = Color.LightGray)
                        }
                    }
                }
            }
        }
    }
}
