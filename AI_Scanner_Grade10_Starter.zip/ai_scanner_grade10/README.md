# AI SCANNER – Grade 10 starter project

This is a **starter source scaffold**, not a production-ready APK. It contains:
- `user-android/`: Android Kotlin/Compose USER app with login, floating overlay permission flow, subject picker, scan placeholder and result dialog.
- `admin-android/`: separate Android Kotlin/Compose ADMIN app with login and management dashboard placeholder.
- `backend/`: FastAPI API scaffold for authentication, accounts, AI provider configuration and scan endpoint.

## Build
1. Open each Android folder in Android Studio (recent version, JDK 17).
2. Configure the backend URL in each app's `BuildConfig` / `ApiConfig`.
3. Run backend:
   ```bash
   cd backend
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn app.main:app --reload
   ```
4. For Android overlay, user must grant **Display over other apps**. Screen capture must use Android MediaProjection consent; this scaffold does not silently capture.
5. Configure a real AI provider only on the backend using environment variables. Never put provider API keys in APKs.

## Security notes
- Demo authentication and storage are placeholders. Replace before deployment.
- Use HTTPS, hashed passwords, JWT expiry/refresh, rate limits, audit logging, and a real database.
- Images should be processed in memory or with short-lived object storage and deleted per retention policy.
- Android may block screenshots in protected apps; don't bypass platform protections.
