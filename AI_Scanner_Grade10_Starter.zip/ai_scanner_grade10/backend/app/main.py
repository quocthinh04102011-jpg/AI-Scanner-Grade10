from datetime import datetime, timezone
from typing import Optional, Literal
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field

app = FastAPI(title="AI Scanner Grade 10 API", version="0.1.0")

# Replace in-memory demo state with PostgreSQL + migrations for production.
users = {
    "demo": {
        "password": "demo1234",  # DEMO ONLY: use Argon2/bcrypt hashes in production
        "role": "USER",
        "active": True,
        "expires_at": None,
        "devices": [],
    },
    "admin": {
        "password": "admin1234", # DEMO ONLY: replace immediately
        "role": "ADMIN",
        "active": True,
        "expires_at": None,
        "devices": [],
    },
}
audit_log = []
ai_config = {"provider": "mock", "model": "mock-grade10", "configured": False}

SUBJECTS = [
    "Toán", "Ngữ văn", "Tiếng Anh", "Vật lý", "Hóa học", "Sinh học",
    "Lịch sử", "Địa lý", "Tin học", "Công nghệ",
    "Giáo dục kinh tế và pháp luật", "Giáo dục quốc phòng và an ninh",
    "Giáo dục thể chất", "Hoạt động trải nghiệm, hướng nghiệp"
]

class LoginRequest(BaseModel):
    username: str
    password: str
    device_id: str = "unknown"

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=8, max_length=128)
    expires_at: Optional[datetime] = None

class UserStatus(BaseModel):
    active: bool

class ScanRequest(BaseModel):
    subject: Optional[str] = None
    language: Literal["vi", "en"] = "vi"
    prompt: str = "Giải bài theo chương trình lớp 10, trình bày từng bước."
    # TODO: add multipart image upload with size/type validation and transient storage

class AIConfigRequest(BaseModel):
    provider: str
    model: str
    # Secret must be accepted through a secure admin-only endpoint and never returned.
    api_key: Optional[str] = None

def admin_required(x_role: str = Header(default="USER")):
    if x_role != "ADMIN":
        raise HTTPException(status_code=403, detail="Admin required")

@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/subjects")
def subjects():
    return {"grade": 10, "subjects": SUBJECTS}

@app.post("/auth/login")
def login(req: LoginRequest):
    user = users.get(req.username)
    if not user or user["password"] != req.password:
        raise HTTPException(status_code=401, detail="Sai tài khoản hoặc mật khẩu")
    if not user["active"]:
        raise HTTPException(status_code=403, detail="Tài khoản đã bị khóa")
    if user["expires_at"] and user["expires_at"] < datetime.now(timezone.utc):
        raise HTTPException(status_code=403, detail="Tài khoản hết hạn")
    if req.device_id not in user["devices"]:
        user["devices"].append(req.device_id)
    audit_log.append({"event": "login", "username": req.username, "at": datetime.now(timezone.utc).isoformat()})
    # TODO: return signed JWT; this demo response is not a token.
    return {"ok": True, "username": req.username, "role": user["role"], "demo_session": True}

@app.post("/scan")
def scan(req: ScanRequest, x_username: str = Header(default="demo")):
    user = users.get(x_username)
    if not user or not user["active"]:
        raise HTTPException(status_code=403, detail="User inactive")
    if req.subject and req.subject not in SUBJECTS:
        raise HTTPException(status_code=400, detail="Môn học không hợp lệ")
    # TODO: validate user entitlement, accept image, call configured vision model,
    # enforce timeout/rate limit, redact logs, delete image immediately after processing.
    audit_log.append({"event": "scan", "username": x_username, "subject": req.subject,
                      "at": datetime.now(timezone.utc).isoformat()})
    return {
        "subject": req.subject or "AI tự nhận diện",
        "answer": "Backend demo: chưa kết nối AI Cloud.",
        "explanation": "Cấu hình nhà cung cấp AI trên backend và bổ sung upload ảnh để nhận lời giải.",
        "grade": 10
    }

@app.post("/admin/users")
def create_user(req: UserCreate, x_role: str = Header(default="USER")):
    admin_required(x_role)
    if req.username in users:
        raise HTTPException(status_code=409, detail="Username đã tồn tại")
    users[req.username] = {"password": req.password, "role": "USER", "active": True,
                           "expires_at": req.expires_at, "devices": []}
    audit_log.append({"event": "user_created", "username": req.username,
                      "at": datetime.now(timezone.utc).isoformat()})
    return {"username": req.username, "active": True, "expires_at": req.expires_at}

@app.patch("/admin/users/{username}/status")
def set_user_status(username: str, req: UserStatus, x_role: str = Header(default="USER")):
    admin_required(x_role)
    if username not in users:
        raise HTTPException(status_code=404, detail="Không tìm thấy tài khoản")
    users[username]["active"] = req.active
    audit_log.append({"event": "user_status", "username": username, "active": req.active,
                      "at": datetime.now(timezone.utc).isoformat()})
    return {"username": username, "active": req.active}

@app.get("/admin/users")
def list_users(x_role: str = Header(default="USER")):
    admin_required(x_role)
    return [{"username": name, "role": u["role"], "active": u["active"],
             "expires_at": u["expires_at"], "devices": u["devices"]}
            for name, u in users.items()]

@app.put("/admin/ai")
def configure_ai(req: AIConfigRequest, x_role: str = Header(default="USER")):
    admin_required(x_role)
    # TODO: persist secret in vault/secret manager; do not echo it.
    ai_config.update({"provider": req.provider, "model": req.model,
                      "configured": bool(req.api_key)})
    audit_log.append({"event": "ai_config_updated", "provider": req.provider,
                      "model": req.model, "at": datetime.now(timezone.utc).isoformat()})
    return {"provider": ai_config["provider"], "model": ai_config["model"],
            "configured": ai_config["configured"]}

@app.get("/admin/audit")
def get_audit(x_role: str = Header(default="USER")):
    admin_required(x_role)
    return audit_log[-200:]
